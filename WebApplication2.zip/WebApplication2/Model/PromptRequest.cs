﻿namespace WebApplication2.Model
{
    public class PromptRequest
    {
        public string Prompt { get; set; }
    }
}
